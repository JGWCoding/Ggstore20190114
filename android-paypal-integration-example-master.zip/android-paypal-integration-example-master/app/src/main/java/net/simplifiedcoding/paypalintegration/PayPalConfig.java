package net.simplifiedcoding.paypalintegration;

/**
 * Created by Belal on 5/1/2016.
 */
public class PayPalConfig {

    public static final String PAYPAL_CLIENT_ID = "PUt Your PayPal Client Id";

}
